package com.example.appinventario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText txtUsuario;
    private EditText txtContraseña;
    private Button bntCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsuario = findViewById(R.id.txtUsuario);
        txtContraseña = findViewById(R.id.txtContraseña);
        bntCalcular = findViewById(R.id.bntIniciar);

    }
    public void iniciaSesion(View view){
        String nombreUsuario = txtUsuario.getText().toString();
        String nombreContraseña = txtContraseña.getText().toString();

        if(nombreUsuario.equals("ale") && nombreContraseña.equals("1")) {
            Toast mensaje = Toast.makeText(this, "Ingreso correcto :)", Toast.LENGTH_SHORT);
            mensaje.show();

            Intent a = new Intent(MainActivity.this, menu_seleccionar_accion.class);
            startActivity(a);
        }
        else{
            Toast error = Toast.makeText(this, "Usuario o contraseña incorrecta :(", Toast.LENGTH_SHORT);
            error.show();
        }

        this.limpiarCajas();

    }
    public void limpiarCajas(){
        txtUsuario.setText("");
        txtContraseña.setText("");
    }
}